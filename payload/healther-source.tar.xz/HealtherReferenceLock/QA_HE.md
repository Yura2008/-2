# Healther · Reference Lock QA — 07.11.2026 (v2)

## Visual
- Approved reference source: `Healther_Complete_Design_References_v1.zip`.
- Frozen 60 light and 60 dark HTML screens; no CSS/style edits on approved sources.
- Chromium 390×844 CSS pixel viewport, DPR=2 (image size 780×1688), RGB per-pixel diff: **120/120 exact** in static/reference browser mode. This does **not** establish Android parity.

## Source / simulated runtime
- Source preflight and JavaScript syntax: PASS.
- Playwright mock bridge tests: **8/8 PASS**, dashboard and 14-day steps in light/dark with sample/no-data test fixtures; no JavaScript page errors.
- Important compile fix: `HealthConnectFeatures` now imports from `androidx.health.connect.client`, not nonexistent `androidx.health.connect.client.feature`.
- Health Connect daily steps aggregated by date (30 days) via official API; no double counting of overlapping phone/watch raw records in daily chart.
- Missing data, last sync, measurement timestamp and permission callback fixed for core dashboard.

## Open blockers / release gate
| Priority | Item | Status |
|--|--|--|
| P0 | Build `app-debug.apk` in real Android SDK/Gradle environment | NOT RUN |
| P0 | Confirm Android permissions compile and run, test Galaxy Watch → Samsung Health → Health Connect | NOT TESTED |
| P0 | Compare screenshot on device to approved reference with actual system insets | NOT TESTED |
| P1 | All 60 dynamic screens bound to real data; remove remaining sample strings | INCOMPLETE |
| P1 | Full 14/30-day history, per-hour steps, sleep-stage breakdown, exercise details, partial coverage | INCOMPLETE |
| P1 | Offline/revoked permissions; stale data; minimum-access and background sync across Android Doze | PARTIAL |
| P2 | Screen sizes 360/390/412 CSS px, 200% fonts, accessibility and RTL numeric order | NOT TESTED |

**No APK is claimed to exist or to have passed native build.** The Colab notebook and GitHub Actions workflow are paths for a real build. Collect on-device evidence before calling visual fidelity verified.
