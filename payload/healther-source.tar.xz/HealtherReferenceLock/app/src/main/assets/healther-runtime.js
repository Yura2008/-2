/* Healther Reference Lock runtime.
 * Source reference HTML/CSS is frozen. All runtime behavior attaches without altering
 * the approved layout before the user interacts. Never label sample as live data.
 */
(() => {
  'use strict';
  const routes = [
    'welcome','privacy_intro','connect','permissions','first_sync','setup_done',
    'dashboard','dashboard_more','metrics_hub','notifications',
    'heart','heart_history','heart_compare','oxygen','oxygen_sleep','oxygen_history',
    'sleep','sleep_night','sleep_history','steps','steps_day','steps_30',
    'activity','workout','activity_history','body','body_history','body_comp',
    'history_hub','history_metric','history_day','history_filter',
    'reports','report_range','report_preview','report_notes','report_export',
    'report_share','export_success','ai_handoff','goals','goal_steps','goal_weight',
    'settings','source_detail','sources','permissions_settings','sync_settings',
    'privacy_settings','appearance','about','empty_all','no_permissions',
    'sync_error','loading','stale','missing_days','offline','dialog_delete','dialog_date'
  ];
  const fileName = location.pathname.split('/').pop() || '07_dashboard.html';
  const dark = fileName.startsWith('dark_');
  const page = fileName.replace(/^dark_/,'').replace(/^\d{2}_/,'').replace(/\.html$/,'');
  const host = window.HealtherHost || null;
  const routeTable = Object.fromEntries(routes.map((name, index) => [name, `${String(index + 1).padStart(2,'0')}_${name}.html`]));
  const navRoutes = { 'בית':'dashboard','מדדים':'metrics_hub','היסטוריה':'history_hub','דוחות':'reports','הגדרות':'settings' };
  const targetByLabel = [
    [/^(דופק|דופק במנוחה)/,'heart'], [/חמצן בדם|חמצן בשינה/,'oxygen'],
    [/^שינה|לילה אחרון|פרטי הלילה/,'sleep'], [/^צעדים|צעדים היום|יעד צעדים/,'steps'],
    [/^פעילות גופנית|תנועה ופעילות/,'activity'], [/^משקל|מעקב משקל/,'body'],
    [/^מקורות מידע|מקורות נתונים|חיבור נתונים/,'sources'],
    [/^ניהול הרשאות|^ניהול גישה|^הרשאות מדדים/,'permissions_settings'],
    [/^סנכרון|^הגדרות סנכרון/,'sync_settings'],
    [/^מראה האפליקציה|^מצב תצוגה/,'appearance'],
    [/^פרטיות|מחיקת היסטוריה/,'privacy_settings'],
    [/^אודות Healther/,'about'],
    [/^יעדים אישיים|^עריכת יעד צעדים/,'goals']
  ];
  function navigate(to) {
    if (!routeTable[to]) return false;
    if (host && typeof host.navigate === 'function') { host.navigate(to); return true; }
    location.href = `${dark ? 'dark_' : ''}${routeTable[to]}`;
    return true;
  }
  const norm = (s) => (s || '').replace(/\s+/g,' ').trim();
  const phrase = el => norm(el.textContent);
  const tell = msg => {
    if (host && host.toast) host.toast(msg);
    else window.alert(msg);
  };
  function nativeCall(fn,...args) {
    if (!host || typeof host[fn] !== 'function') {
      tell('פעולה זו זמינה באפליקציית Android לאחר חיבור ל־Health Connect.');
      return false;
    }
    host[fn](...args);
    return true;
  }
  function fallbackRoute(label) {
    for (const [rx,target] of targetByLabel) if (rx.test(label)) return target;
    return null;
  }
  function onNavigation(e) {
    const nav=e.target.closest('.nav-item');
    if (nav) { const to=navRoutes[phrase(nav)]; if(to){navigate(to);return;} }
    if (e.target.closest('.top-icon')) { navigate('notifications'); return; }
    const brand=e.target.closest('.wordmark'); if(brand){navigate('dashboard');return;}
    const btn=e.target.closest('.button');
    if (btn) {
      const t=phrase(btn);
      if (t.includes('מתחילים')) return navigate('privacy_intro');
      if (t.includes('ממשיכים')) return navigate('connect');
      if (t.includes('חיבור ל־Health Connect')) return navigate('permissions');
      if (t.includes('פתיחת בקשת הרשאות') || t.includes('פתיחת הגדרות הרשאה')) {
        nativeCall('requestPermissions'); return;
      }
      if (t.includes('מעבר למסך הבית')) return navigate('dashboard');
      if (t.includes('סנכרון ידני')) return nativeCall('syncNow');
      if (t.includes('היסטוריית מדידות')) return navigate(page==='heart' ? 'heart_history' : page==='oxygen' ? 'oxygen_history' : 'history_hub');
      if (t.includes('היסטוריית לילות')) return navigate('sleep_history');
      if (t.includes('היסטוריית כל המדדים')) return navigate('history_hub');
      if (t.includes('יצירת דוח')) return navigate('report_range');
      if (t.includes('תצוגה מקדימה')) return navigate('report_preview');
      if (t.includes('המשך לייצוא')) return navigate('report_notes');
      if (t.includes('שמירת ההערות')) {
        const el=document.querySelector('.field.textarea');
        const note=el?.innerText || '';
        if (host?.setReportNote) host.setReportNote(note);
        return navigate('report_export');
      }
      if (t.includes('שמירת קובץ')) return nativeCall('exportReport',window.__healtherReportType || 'md');
      if (t.includes('שיתוף עם אפליקציה')) return nativeCall('shareReport',window.__healtherReportType || 'md');
      if (t.includes('שמירת יעד')) {
        const num=Number(window.__healtherGoal || 10000);
        if (host?.saveGoal) host.saveGoal(num);
        tell('יעד הצעדים נשמר במכשיר.');return navigate('goals');
      }
      if (t==='ביטול') return navigate('privacy_settings');
      if (t==='מחיקת ההיסטוריה') return nativeCall('deleteLocalHistory');
      if (t.includes('בחירת טווח')) return navigate('history_hub');
      return;
    }
    // Invisible behavior only: the exact reference pixels remain unchanged.
    if (page==='dashboard') {
      if (e.target.closest('.hero-steps')) return navigate('steps');
      const card=e.target.closest('.card');
      if(card){
        const text=phrase(card);
        if (card.closest('.duo')) return navigate(text.includes('חמצן')?'oxygen':'heart');
        if (text.includes('שעות שינה')) return navigate('sleep');
        if (text.includes('תנועה ופעילות')) return navigate('activity');
        if (text.includes('המדידה האחרונה') && text.includes('ק״ג')) return navigate('body');
        if (text.includes('צעדים השבוע')) return navigate('steps');
      }
    }
    const section=e.target.closest('.section-more');
    if (section) {
      const t=phrase(section);
      if (t.includes('לכל המדדים')) return navigate('metrics_hub');
      if (t.includes('פרטי הלילה') || t.includes('פירוט הלילה')) return navigate('sleep_night');
      if (t.includes('לפרטי המדד')) return navigate('body');
      if (t.includes('לכל ההיסטוריה')) return navigate('history_hub');
      if (t.includes('ליום נבחר')) return navigate('steps_day');
    }
    const row=e.target.closest('.metric-row,.list-row,.share-target');
    if(row) {
      const t=phrase(row);
      if (row.classList.contains('share-target')) {
        if(t.includes('שמירה')) return nativeCall('exportReport',window.__healtherReportType||'md');
        return nativeCall('shareReport',window.__healtherReportType||'md');
      }
      const explicit={
        'יעדים אישיים':'goals','עריכת יעד צעדים':'goal_steps','מעקב משקל':'goal_weight',
        'מקורות מידע':'sources','ניהול הרשאות':'permissions_settings',
        'מראה האפליקציה':'appearance','אודות Healther':'about',
        'פרטיות ושמירת נתונים':'privacy_settings','ייצוא מידע מקומי':'report_export',
        'מחיקת היסטוריה':'dialog_delete','דופק במנוחה':'heart_history',
        'הרכב גוף':'body_comp','שינה':'sleep','היסטוריית מדידות':'history_hub'
      };
      for(const [key,target] of Object.entries(explicit)) if(t.startsWith(key))return navigate(target);
      const target=fallbackRoute(t); if(target) return navigate(target);
    }
  }
  document.addEventListener('click',onNavigation);
  document.querySelectorAll('.chip').forEach(chip=>chip.addEventListener('click',()=>{
    const group=chip.parentElement;
    group?.querySelectorAll('.chip').forEach(x=>x.classList.remove('on'));
    chip.classList.add('on');
    const txt=phrase(chip);
    if (page==='goal_steps' && /^\d/.test(txt))window.__healtherGoal=Number(txt.replace(/,/g,''));
    if(/^יום$/.test(txt))selectedRange=1;
    else if(/^7/.test(txt))selectedRange=7;
    else if(/^14/.test(txt))selectedRange=14;
    else if(/^30/.test(txt))selectedRange=30;
    if(lastSnapshot)updateCharts(lastSnapshot);
    if (txt.includes('טווח אחר') || txt.includes('מותאם'))navigate('dialog_date');
  }));
  // Preserve all styling; annotate editable or switch-like prototypes only after interaction.
  document.querySelectorAll('.field.textarea').forEach(el => {
    el.setAttribute('contenteditable','true');el.setAttribute('role','textbox');
    el.setAttribute('aria-label','הערות לדוח');
    el.addEventListener('input',() => { if(el.innerText.length>2000)el.innerText=el.innerText.slice(0,2000); });
  });
  if(page==='report_export'){
    document.querySelectorAll('.card .list-row, .card .metric-row').forEach(row=>row.addEventListener('click',()=>{
      const t=phrase(row); if(t.includes('Markdown')||t.includes('JSON')){
        window.__healtherReportType=t.includes('JSON')?'json':'md';
      }
    }));
  }
  if(page==='appearance'){
    document.querySelectorAll('.card .list-row').forEach(row=>row.addEventListener('click',()=>{
      const s=phrase(row),mode=s.includes('כהה')?'dark':s.includes('בהיר')?'light':'system';
      if(host?.setTheme)host.setTheme(mode); else navigate('dashboard');
    }));
  }
  if(page==='sync_settings'){
    document.querySelectorAll('.toggle').forEach((toggle,i)=>toggle.addEventListener('click',()=>{
      if (i===0 && host?.setAutoSync)host.setAutoSync(!toggle.classList.contains('on'));
      toggle.classList.toggle('on');
    }));
  }
  let lastSnapshot=null;
  let selectedRange=14;
  function makeRealChart(svg,records,key) {
    const periodStart=Date.now()-selectedRange*86400000;
    const relevant=records.filter(r=>r.metric===key && Number(r.epochMillis)>=periodStart)
      .sort((a,b)=>Number(a.epochMillis)-Number(b.epochMillis));
    if(!relevant.length)return false;
    const ns='http://www.w3.org/2000/svg';
    const box=svg.viewBox.baseVal;
    const w=box.width||340,h=box.height||150,pad={l:18,r:16,t:15,b:26};
    if(w<=40||h<=40)return false;
    const colors={heart_rate:'#B44459',oxygen_saturation:'#217B8D',steps:'#327A56',
      sleep:'#7963BC',weight:'#3F709D',workout:'#C58241'};
    const color=colors[key]||'#327A56';
    svg.replaceChildren();svg.style.visibility='visible';
    const el=(tag,attrs,parent=svg)=>{
      const node=document.createElementNS(ns,tag);
      Object.entries(attrs).forEach(([k,v])=>node.setAttribute(k,String(v)));
      parent.appendChild(node);return node;
    };
    for(let i=0;i<=3;i++){
      const y=pad.t+(h-pad.t-pad.b)*i/3;
      el('path',{d:`M${pad.l} ${y}H${w-pad.r}`,stroke:'var(--line)',
        'stroke-width':1,'stroke-dasharray':'3 4'});
    }
    let points=[];
    if(key==='steps'||key==='sleep'||key==='workout'){
      const byDay=new Map();
      relevant.forEach(r=>{
        const day=new Date(Number(r.epochMillis)).toLocaleDateString('sv-SE');
        byDay.set(day,(byDay.get(day)||0)+(Number(r.value)||0));
      });
      const days=Array.from({length:selectedRange},(_,i)=>{
        const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()-(selectedRange-1-i));
        return d.toLocaleDateString('sv-SE');
      });
      const max=Math.max(1,...byDay.values());
      const slot=(w-pad.l-pad.r)/days.length;
      days.forEach((day,i)=>{
        const val=byDay.get(day);
        if(val==null)return; // missing is a gap, never a zero-height data point
        const height=(h-pad.t-pad.b)*val/max;
        const rect=el('rect',{x:pad.l+i*slot+slot*.16,y:h-pad.b-height,
          width:slot*.68,height:Math.max(1,height),rx:Math.min(3,slot*.12),fill:color});
        rect.style.cursor='pointer';
        rect.addEventListener('click',()=>tell(`${day}: ${Number(val).toLocaleString('he-IL')} ${key==='steps'?'צעדים':key==='sleep'?'דקות שינה':'אימונים'}`));
      });
    } else {
      const vals=relevant.map(r=>Number(r.value)).filter(Number.isFinite);
      if(!vals.length)return false;
      const min=Math.min(...vals),max=Math.max(...vals);
      const low=min===max?min-1:min-(max-min)*.12;
      const hi=max===min?max+1:max+(max-min)*.12;
      const t0=Number(relevant[0].epochMillis),t1=Number(relevant[relevant.length-1].epochMillis);
      points=relevant.filter(r=>Number.isFinite(Number(r.value))).map(r=>({
        x:pad.l+(w-pad.l-pad.r)*(Number(r.epochMillis)-t0)/Math.max(1,t1-t0),
        y:pad.t+(h-pad.t-pad.b)*(hi-Number(r.value))/Math.max(.01,hi-low),r
      }));
      let path='',last=null;
      points.forEach(pt=>{
        const gap=last?Number(pt.r.epochMillis)-Number(last.r.epochMillis):0;
        const cutoff=selectedRange<=1?4*3600000:2*86400000;
        path+=(last && gap<=cutoff?'L':'M')+pt.x.toFixed(2)+','+pt.y.toFixed(2)+' ';
        last=pt;
      });
      el('path',{d:path,fill:'none',stroke:color,'stroke-width':2.4,
        'stroke-linejoin':'round','stroke-linecap':'round'});
      points.forEach(pt=>{
        const circle=el('circle',{cx:pt.x,cy:pt.y,r:3.8,fill:color,stroke:'var(--surface)',
          'stroke-width':1.5});
        circle.addEventListener('click',()=>tell(`${pt.r.value} ${pt.r.unit} · ${new Date(Number(pt.r.epochMillis)).toLocaleString('he-IL')}`));
      });
    }
    const labels=selectedRange<=1?['תחילת היום','עכשיו']:[`${selectedRange} ימים אחורה`,'היום'];
    el('text',{x:pad.l,y:h-5,fill:'var(--muted)','font-size':10}).textContent=labels[0];
    el('text',{x:w-pad.r,y:h-5,fill:'var(--muted)','font-size':10,
      'text-anchor':'end'}).textContent=labels[1];
    svg.setAttribute('aria-label','נתונים אמיתיים מ־Health Connect, לפי חותמות זמן');
    return true;
  }
  function renderDailyStepBars(svg,s) {
    if(!['steps','steps_30'].includes(page))return false;
    const all=s.dailySteps&&typeof s.dailySteps==='object'?s.dailySteps:{};
    const bars=[...svg.querySelectorAll('rect')].filter(r=>Number(r.getAttribute('y'))<160);
    if(bars.length!==14)return false;
    const dates=Array.from({length:14},(_,i)=>{
      const d=new Date();d.setHours(12,0,0,0);
      d.setDate(d.getDate()-(page==='steps'?13-i:Math.round((13-i)*29/13)));
      return {key:[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),
        String(d.getDate()).padStart(2,'0')].join('-'),day:d.getDate()};
    });
    const counts=dates.map(d=>all[d.key]);
    const max=Math.max(1,...counts.map(n=>Number(n)||0));
    bars.forEach((bar,i)=>{
      const num=counts[i],height=num==null?14:Math.max(2,142*Number(num)/max);
      bar.setAttribute('y',String(157-height));
      bar.setAttribute('height',String(height));
      bar.setAttribute('opacity',i===13?'1':'.65');
      if(num==null){
        bar.setAttribute('fill','none');bar.setAttribute('stroke','var(--muted)');
        bar.setAttribute('stroke-dasharray','2 2');
      }else{
        bar.setAttribute('fill','#307B52');bar.removeAttribute('stroke');
        bar.removeAttribute('stroke-dasharray');
      }
      bar.addEventListener('click',()=>tell(num==null?`${dates[i].key}: אין נתונים`:
        `${dates[i].key}: ${Number(num).toLocaleString('en-US')} צעדים`));
    });
    const texts=[...svg.querySelectorAll('text')];
    texts.forEach((t,i)=>{
      const x=Number(t.getAttribute('x'));
      if(Number.isFinite(x)&&i<7)t.textContent=String(dates[Math.min(i*2,13)].day);
    });
    svg.setAttribute('aria-label',page==='steps'?'צעדים ל-14 ימים לפי Health Connect':
      'צעדים ב-30 ימים לפי Health Connect, 14 נקודות זמן');
    return true;
  }
  function updateCharts(s){
    const key=({heart:'heart_rate',heart_history:'heart_rate',heart_compare:'heart_rate',
      oxygen:'oxygen_saturation',oxygen_history:'oxygen_saturation',
      sleep:'sleep',sleep_history:'sleep',sleep_night:'sleep',
      steps:'steps',steps_day:'steps',steps_30:'steps',
      body:'weight',body_history:'weight',activity:'workout',
      activity_history:'workout',history_metric:'steps',dashboard:'sleep'})[page];
    const records=Array.isArray(s.records)?s.records:[];
    document.querySelectorAll('.chart-svg').forEach(svg=>{
      const supported=key && !(page==='dashboard') &&
        ((key==='steps'&&renderDailyStepBars(svg,s)) ||
        (key!=='steps'&&makeRealChart(svg,records,key)));
      if(!supported){svg.style.visibility='hidden';}
    });
    document.querySelectorAll('.micro-bars').forEach(bar=>{
      // Only validated Health Connect daily aggregates; raw phone/watch records can overlap.
      const days=s.dailySteps && typeof s.dailySteps==='object'?s.dailySteps:{};
      const elements=[...bar.querySelectorAll('.micro-b')];
      const dates=Array.from({length:elements.length},(_,i)=>{
        const d=new Date();d.setHours(12,0,0,0);
        d.setDate(d.getDate()-(elements.length-1-i));
        return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
      });
      const max=Math.max(1,...dates.map(d=>Number(days[d])||0));
      elements.forEach((el,i)=>{
        const col=el.querySelector('.micro-col'),value=days[dates[i]];
        if(!col)return;
        col.style.height=value==null?'0':Math.round(60*Number(value)/max)+'px';
        col.style.opacity=value==null?'0':'.9';
        el.addEventListener('click',()=>tell(value==null?`${dates[i]}: אין נתונים`:
          `${dates[i]}: ${Number(value).toLocaleString('en-US')} צעדים`));
      });
      bar.style.visibility='visible';
    });
  }
  function applySnapshot(s) {
    if (!host) return;
    lastSnapshot=s;
    const badge=document.querySelector('.demo-badge');
    if (badge)badge.textContent=s.error?'סנכרון חלקי':(s.syncedAt?'נתונים מסונכרנים':'אין מדידות מסונכרנות');
    // All reference values are demo; in the installed app replace them unless backed by a real record.
    const values={
      heart:s.latestHeart?.value,oxygen:s.latestOxygen?.value,
      steps:s.todaySteps?.value,sleep:s.lastSleep?.value,body:s.latestWeight?.value,
      activity:s.workoutsToday?.value
    };
    const num=(value,metric)=>value==null?'—':metric==='steps'?Number(value).toLocaleString('en-US'):
       metric==='sleep'?Math.floor(value/60)+':'+String(Math.round(value)%60).padStart(2,'0'):
       metric==='body'?Number(value).toFixed(1):String(Math.round(Number(value)));
    const metricKey=(text)=>{
      if(/חמצן/.test(text))return 'oxygen';if(/דופק/.test(text))return 'heart';
      if(/שינה|לילה/.test(text))return 'sleep';if(/צעדים/.test(text))return 'steps';
      if(/משקל|הרכב גוף/.test(text))return 'body';if(/פעילות|אימונים/.test(text))return 'activity';
      return null;
    };
    // Explicit metric bindings for headings and cards; no data means em dash, never zero.
    document.querySelectorAll('.metric-row').forEach(row=>{
      const key=metricKey(phrase(row.querySelector('.metric-title')||row));
      const out=row.querySelector('.metric-value');
      if(key&&out)out.textContent=num(values[key],key);
    });
    document.querySelectorAll('.duo .card').forEach(card=>{
      const key=metricKey(phrase(card.querySelector('.tile-name'))),out=card.querySelector('.tile-num');
      if(key&&out)out.firstChild.textContent=num(values[key],key);
    });
    if (page==='dashboard'||page==='dashboard_more'||page==='goals') {
      const hero=document.querySelector('.hero-val'); if(hero)hero.textContent=num(values.steps,'steps');
      const ring=document.querySelector('.ring');
      if(ring) {
        ring.style.setProperty('--percent',values.steps==null?0:Math.min(100,values.steps/(s.stepGoal||10000)*100));
        const ringText=ring.querySelector('strong'); if(ringText)ringText.textContent=values.steps==null?'—':Math.round(values.steps/(s.stepGoal||10000)*100)+'%';
      }
      document.querySelectorAll('.card').forEach(card=>{
        const text=phrase(card),val=card.querySelector('.big-num');
        if(val&&text.includes('ק״ג'))val.textContent=num(values.body,'body');
        if(val&&text.includes('שינה'))val.textContent=num(values.sleep,'sleep');
      });
    }
    const single={heart:'heart',heart_history:'heart',heart_compare:'heart',oxygen:'oxygen',oxygen_sleep:'oxygen',
      oxygen_history:'oxygen',sleep:'sleep',sleep_night:'sleep',sleep_history:'sleep',steps:'steps',steps_day:'steps',steps_30:'steps',
      body:'body',body_history:'body',body_comp:'body',activity:'activity'}[page];
    if(single){
      const out=document.querySelector('.big-num,.hero-val');
      if(out)out.textContent=num(values[single],single);
    }
    // Reference charts contain sample data. Hide them until replaced with true timestamped series.
    document.querySelectorAll('.chart-svg, .micro-bars').forEach(chart=>{
      chart.style.visibility='hidden';
      chart.setAttribute('aria-label','גרף יופיע רק אם קיימות רשומות אמיתיות.');
    });
    updateCharts(s);
    // Prevent remaining dashboard demo values/times from masquerading as measurements.
    if(page==='dashboard') {
      const localTime=(iso)=>{
        if(!iso)return 'אין מדידה זמינה';
        const d=new Date(iso);
        return Number.isNaN(d.getTime())?'זמן מדידה לא זמין':
          'מדידה אחרונה · '+d.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'});
      };
      document.querySelectorAll('.duo .card').forEach(card=>{
        const key=metricKey(phrase(card.querySelector('.tile-name')));
        const measured=(key==='heart'?s.latestHeart:key==='oxygen'?s.latestOxygen:null);
        const caption=card.querySelector('.tile-caption');
        if(caption)caption.textContent=localTime(measured?.measuredAt);
      });
      const goal=s.stepGoal||10000;
      const heroSub=document.querySelector('.hero-steps .hero-sub');
      if(heroSub)heroSub.textContent='מתוך יעד של '+Number(goal).toLocaleString('en-US')+' צעדים';
      const remaining=document.querySelector('.hero-steps .pill-steps');
      if(remaining)remaining.textContent=values.steps==null?'אין נתוני צעדים להיום':
        Math.max(0,goal-Number(values.steps)).toLocaleString('en-US')+' צעדים ליעד';
      const sleepTime=document.querySelector('.wide-metric .row-stat .strong');
      if(sleepTime)sleepTime.textContent=num(values.sleep,'sleep');
      const sleepPill=document.querySelector('.wide-metric .pill');
      if(sleepPill)sleepPill.textContent='שעות שינה'; // Sleep start/end are not yet stored.
      const weightTime=document.querySelector('.metric-time');
      if(weightTime)weightTime.textContent=s.latestWeight?.measuredAt?
        new Date(s.latestWeight.measuredAt).toLocaleString('he-IL'):'אין מדידה זמינה';
      const activity=[s.workoutsToday?.value,s.activeCaloriesToday?.value,s.distanceToday?.value];
      document.querySelectorAll('.stats .stat-number').forEach((el,i)=>{
        if(el.firstChild?.nodeType===Node.TEXT_NODE){
          const v=activity[i];
          el.firstChild.textContent=v==null?'—':i===2?Number(v).toFixed(1):
             i===1?Math.round(Number(v)).toLocaleString('en-US'):String(Number(v));
        }
      });
      const daily=s.dailySteps&&typeof s.dailySteps==='object'?s.dailySteps:{};
      const last7=Array.from({length:7},(_,i)=>{
        const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()-(6-i));
        return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
      });
      const observed=last7.map(k=>daily[k]).filter(v=>v!=null);
      const avg=document.querySelector('.micro-bars')?.closest('.card')?.querySelector('.pill');
      if(avg)avg.textContent=observed.length?
        'ממוצע '+Math.round(observed.reduce((a,b)=>a+Number(b),0)/observed.length).toLocaleString('en-US'):
        'אין מדידות לשבוע';
      document.querySelectorAll('.infobar').forEach((el,i)=>{
        const t=el.querySelector('span');if(!t)return;
        if(i===0)t.textContent=s.syncedAt?
          'סנכרון אחרון · '+new Date(s.syncedAt).toLocaleString('he-IL'):
          'עדיין לא בוצע סנכרון עם Health Connect';
        else t.textContent='מוצגות רק מדידות שהתקבלו ממקור מורשה. מידע חסר מסומן בקו מפריד.';
      });
    } else {
      // Dynamic substatistics not bound to a verified aggregate must not keep demo counts.
      document.querySelectorAll('.stats .stat-number,.subtile-val').forEach(item=>{
        if(item.firstChild?.nodeType===Node.TEXT_NODE)item.firstChild.textContent='—';
      });
    }
    if(page==='steps'||page==='steps_30') {
      const all=s.dailySteps&&typeof s.dailySteps==='object'?s.dailySteps:{};
      const span=page==='steps'?14:30;
      const days=Array.from({length:span},(_,i)=>{
        const d=new Date();d.setDate(d.getDate()-(span-1-i));
        return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),
          String(d.getDate()).padStart(2,'0')].join('-');
      });
      const found=days.map(d=>all[d]).filter(v=>v!=null).map(Number);
      const total=found.reduce((a,b)=>a+b,0);
      const counts=[found.length?Math.round(total/found.length):null,
        found.length?total:null,
        found.length?found.filter(v=>v>=Number(s.stepGoal||10000)).length:null];
      document.querySelectorAll('.stats .stat-number').forEach((el,i)=>{
        if(el.firstChild?.nodeType===Node.TEXT_NODE)el.firstChild.textContent=
          counts[i]==null?'—':Number(counts[i]).toLocaleString('en-US');
      });
    }
    if(!s.syncedAt) {
      document.querySelectorAll('.tile-num,.big-num,.hero-val,.metric-value').forEach(node=>{
        // Do not replace labels, units or icons; only the demo numeric content.
        if(node.firstChild?.nodeType===Node.TEXT_NODE)node.firstChild.textContent='—';
      });
    }
  }
  if(host&&typeof host.getSnapshot==='function') {
    try {applySnapshot(JSON.parse(host.getSnapshot()||'{}'));} catch(ex) {console.warn('Healther snapshot unavailable',ex);}
    if(page==='first_sync')host.syncNow();
  }
  window.HealtherReferenceLock={page,navigate,applySnapshot};
})();
