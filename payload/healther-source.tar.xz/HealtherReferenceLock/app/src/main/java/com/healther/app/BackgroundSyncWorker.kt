package com.healther.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.HealthConnectFeatures
import androidx.health.connect.client.permission.HealthPermission
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class BackgroundSyncWorker(context:Context, params:WorkerParameters):CoroutineWorker(context,params) {
    override suspend fun doWork():Result = if(HealthStore.synchronize(applicationContext))Result.success() else Result.retry()
}

object BackgroundScheduling {
    private const val NAME="healther_health_connect_background"
    suspend fun setEnabled(context:Context, enabled:Boolean):Boolean {
        val wm=WorkManager.getInstance(context)
        if (!enabled) {wm.cancelUniqueWork(NAME); return true}
        if (!HealthStore.available(context))return false
        val hc=HealthConnectClient.getOrCreate(context)
        val supported=hc.features.getFeatureStatus(HealthConnectFeatures.FEATURE_READ_HEALTH_DATA_IN_BACKGROUND)==
            HealthConnectFeatures.FEATURE_STATUS_AVAILABLE
        val permission=HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND
        if(!supported || permission !in hc.permissionController.getGrantedPermissions()) return false
        val request=PeriodicWorkRequestBuilder<BackgroundSyncWorker>(1,TimeUnit.HOURS).build()
        wm.enqueueUniquePeriodicWork(NAME,ExistingPeriodicWorkPolicy.KEEP,request)
        return true
    }
}
