package com.healther.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.AggregateGroupByPeriodRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.Period
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

/** One local source-of-truth. There is no fake live sample data in the installed app. */
object HealthStore {
    const val PREFS = "healther_local_v1"
    private const val KEY_RECORDS = "records"
    private const val KEY_LAST_SYNC = "last_sync"
    private const val KEY_LAST_ERROR = "last_error"
    private const val KEY_GOAL = "step_goal"

    val recordPermissions: Set<String> = setOf(
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class)
    )

    fun available(context: Context): Boolean =
        HealthConnectClient.getSdkStatus(context) == HealthConnectClient.SDK_AVAILABLE

    fun goal(context: Context): Int = context.getSharedPreferences(PREFS,0).getInt(KEY_GOAL,10000)
    fun setGoal(context: Context, goal: Int) {
        require(goal in 1000..100000)
        context.getSharedPreferences(PREFS,0).edit().putInt(KEY_GOAL,goal).apply()
    }
    fun clear(context: Context) {
        context.getSharedPreferences(PREFS,0).edit()
            .remove(KEY_RECORDS).remove(KEY_LAST_SYNC).remove(KEY_LAST_ERROR)
            .remove("steps_aggregate_day").remove("steps_aggregate_value")
            .remove("steps_daily_aggregated").putBoolean("auto_sync",false).apply()
    }

    private fun data(metric: String, value: Number, unit: String, time: Instant,
                     source: String, recordId: String): JSONObject = JSONObject().apply {
        put("recordId",recordId)
        put("metric",metric)
        put("value",value)
        put("unit",unit)
        put("measuredAt",time.atZone(ZoneId.systemDefault()).toOffsetDateTime().toString())
        put("epochMillis",time.toEpochMilli())
        put("source",source)
        put("availability","recorded")
        put("sample",false)
    }

    private suspend inline fun <reified T : Record> readAll(
        client: HealthConnectClient, start: Instant, end: Instant,
        crossinline visit: (T)->Unit
    ) {
        var next: String? = null
        var pages = 0
        do {
            val response = client.readRecords(
                ReadRecordsRequest(recordType=T::class,
                    timeRangeFilter=TimeRangeFilter.between(start,end),
                    pageSize=500, pageToken=next)
            )
            response.records.forEach(visit)
            next = response.pageToken
            pages++
        } while (next != null && pages < 100)
    }

    /** Only uses user-granted permissions. All absent sources stay absent, never 0. */
    suspend fun synchronize(context: Context): Boolean = withContext(Dispatchers.IO) {
        val pref = context.getSharedPreferences(PREFS,0)
        if (!available(context)) {
            pref.edit().putString(KEY_LAST_ERROR,"Health Connect אינו זמין במכשיר").apply()
            return@withContext false
        }
        try {
            val client=HealthConnectClient.getOrCreate(context)
            val granted=client.permissionController.getGrantedPermissions()
            if (granted.intersect(recordPermissions).isEmpty()) {
                pref.edit().putString(KEY_LAST_ERROR,"לא ניתנו הרשאות לקריאת מדדי הבריאות").apply()
                return@withContext false
            }
            val now=Instant.now()
            val start=now.minus(30,ChronoUnit.DAYS)
            val old=JSONArray(pref.getString(KEY_RECORDS,"[]"))
            val byId=LinkedHashMap<String,JSONObject>()
            for (i in 0 until old.length()) {
                val item=old.optJSONObject(i) ?: continue
                val key="${item.optString("source")}:${item.optString("metric")}:${item.optString("recordId")}";
                if (item.optLong("epochMillis",0)>start.toEpochMilli()) byId[key]=item
            }
            fun add(obj:JSONObject) {
                val key="${obj.optString("source")}:${obj.optString("metric")}:${obj.optString("recordId")}";
                byId[key]=obj
            }
            val errors=mutableListOf<String>()
            suspend fun attempt(permission:String, metric:String, work:suspend()->Unit) {
                if(permission in granted) {
                    runCatching {work()}.onFailure {errors += "$metric: ${it.javaClass.simpleName}"}
                }
            }
            attempt(HealthPermission.getReadPermission(HeartRateRecord::class),"heart_rate") {
                readAll<HeartRateRecord>(client,start,now) { record ->
                    record.samples.forEach { sample ->
                        add(data("heart_rate",sample.beatsPerMinute,"bpm",sample.time,
                            record.metadata.dataOrigin.packageName,"${record.metadata.id}:${sample.time.toEpochMilli()}"))
                    }
                }
            }
            attempt(HealthPermission.getReadPermission(OxygenSaturationRecord::class),"oxygen_saturation") {
                readAll<OxygenSaturationRecord>(client,start,now) { record ->
                    add(data("oxygen_saturation",record.percentage.value,"%",record.time,
                        record.metadata.dataOrigin.packageName,record.metadata.id))
                }
            }
            attempt(HealthPermission.getReadPermission(StepsRecord::class),"steps") {
                readAll<StepsRecord>(client,start,now) { record ->
                    add(data("steps",record.count,"steps",record.startTime,
                        record.metadata.dataOrigin.packageName,record.metadata.id))
                }
            }
            attempt(HealthPermission.getReadPermission(SleepSessionRecord::class),"sleep") {
                readAll<SleepSessionRecord>(client,start,now) { record ->
                    add(data("sleep",Duration.between(record.startTime,record.endTime).toMinutes(),
                        "min",record.endTime,record.metadata.dataOrigin.packageName,record.metadata.id))
                }
            }
            attempt(HealthPermission.getReadPermission(WeightRecord::class),"weight") {
                readAll<WeightRecord>(client,start,now) { record ->
                    add(data("weight",record.weight.inKilograms,"kg",record.time,
                        record.metadata.dataOrigin.packageName,record.metadata.id))
                }
            }
            attempt(HealthPermission.getReadPermission(ExerciseSessionRecord::class),"workout") {
                readAll<ExerciseSessionRecord>(client,start,now) { record ->
                    add(data("workout",1,"session",record.startTime,
                        record.metadata.dataOrigin.packageName,record.metadata.id))
                }
            }
            attempt(HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),"active_calories") {
                readAll<ActiveCaloriesBurnedRecord>(client,start,now) { record ->
                    add(data("active_calories",record.energy.inKilocalories,"kcal",record.startTime,
                        record.metadata.dataOrigin.packageName,record.metadata.id))
                }
            }
            attempt(HealthPermission.getReadPermission(DistanceRecord::class),"distance") {
                readAll<DistanceRecord>(client,start,now) { record ->
                    add(data("distance",record.distance.inKilometers,"km",record.startTime,
                        record.metadata.dataOrigin.packageName,record.metadata.id))
                }
            }
            // Prefer the official aggregate for today's steps: Health Connect applies data-source priority.
            val today=LocalDate.now(ZoneId.systemDefault())
            val todayStart=today.atStartOfDay(ZoneId.systemDefault()).toInstant()
            val canReadSteps=HealthPermission.getReadPermission(StepsRecord::class) in granted
            val aggregateSteps=if(canReadSteps) {
                runCatching {
                    client.aggregate(AggregateRequest(
                        metrics=setOf(StepsRecord.COUNT_TOTAL),
                        timeRangeFilter=TimeRangeFilter.between(todayStart,now)
                    ))[StepsRecord.COUNT_TOTAL]
                }.onFailure {errors += "steps_aggregate: ${it.javaClass.simpleName}"}.getOrNull()
            } else null
            // Aggregate by local calendar days, not raw records from multiple sources.
            // Health Connect applies its source-priority rules to prevent double-counting.
            val dailySteps=if(canReadSteps) {
                runCatching {
                    val dayStart=today.minusDays(29).atStartOfDay()
                    val buckets=client.aggregateGroupByPeriod(AggregateGroupByPeriodRequest(
                        metrics=setOf(StepsRecord.COUNT_TOTAL),
                        timeRangeFilter=TimeRangeFilter.between(dayStart,LocalDateTime.now()),
                        timeRangeSlicer=Period.ofDays(1)
                    ))
                    JSONObject().apply {
                        buckets.forEach { bucket ->
                            bucket.result[StepsRecord.COUNT_TOTAL]?.let { count ->
                                put(bucket.startTime.toLocalDate().toString(),count)
                            }
                        }
                    }
                }.onFailure {errors += "steps_daily: ${it.javaClass.simpleName}"}.getOrNull()
            } else null
            val sorted=byId.values.sortedBy {it.optLong("epochMillis",0)}
            val json=JSONArray();sorted.forEach(json::put)
            val editor=pref.edit()
            if(aggregateSteps!=null) {
                editor.putString("steps_aggregate_day",today.toString())
                editor.putLong("steps_aggregate_value",aggregateSteps)
            } else {
                editor.remove("steps_aggregate_day").remove("steps_aggregate_value")
            }
            if(dailySteps!=null) editor.putString("steps_daily_aggregated",dailySteps.toString())
            else editor.remove("steps_daily_aggregated")
            editor
                .putString(KEY_RECORDS,json.toString())
                .putString(KEY_LAST_SYNC,ZonedDateTime.now().toOffsetDateTime().toString())
                .putString(KEY_LAST_ERROR,errors.joinToString("; "))
                .apply()
            true
        } catch(e:Exception) {
            pref.edit().putString(KEY_LAST_ERROR,e.message?:e.javaClass.simpleName).apply()
            false
        }
    }

    fun snapshot(context:Context): JSONObject {
        val pref=context.getSharedPreferences(PREFS,0)
        val arr=runCatching {JSONArray(pref.getString(KEY_RECORDS,"[]"))}.getOrElse {JSONArray()}
        val all=(0 until arr.length()).mapNotNull(arr::optJSONObject)
        val today=LocalDate.now(ZoneId.systemDefault())
        fun latest(metric:String):JSONObject? = all.filter {it.optString("metric")==metric}
            .maxByOrNull {it.optLong("epochMillis",0)}
        fun v(item:JSONObject?):JSONObject? = item?.let {
            JSONObject().put("value",it.get("value")).put("measuredAt",it.optString("measuredAt"))
                .put("source",it.optString("source"))
        }
        fun sumToday(metric:String):JSONObject? {
            val items=all.filter {
                it.optString("metric")==metric &&
                    Instant.ofEpochMilli(it.optLong("epochMillis",0)).atZone(ZoneId.systemDefault()).toLocalDate()==today
            }
            if(items.isEmpty())return null
            return JSONObject().put("value",items.sumOf {it.optDouble("value",0.0)})
        }
        return JSONObject().apply {
            put("app","Healther")
            put("schemaVersion","1.0")
            put("syncedAt",pref.getString(KEY_LAST_SYNC,null) ?: JSONObject.NULL)
            put("error",pref.getString(KEY_LAST_ERROR,"") ?: "")
            put("stepGoal",goal(context))
            put("latestHeart",v(latest("heart_rate"))?:JSONObject.NULL)
            put("latestOxygen",v(latest("oxygen_saturation"))?:JSONObject.NULL)
            put("latestWeight",v(latest("weight"))?:JSONObject.NULL)
            put("lastSleep",v(latest("sleep"))?:JSONObject.NULL)
            val aggDay=pref.getString("steps_aggregate_day",null)
            val agg=if(aggDay==today.toString() && pref.contains("steps_aggregate_value"))
                JSONObject().put("value",pref.getLong("steps_aggregate_value",0L)) else null
            put("todaySteps",agg?:JSONObject.NULL)
            put("dailySteps",JSONObject(pref.getString("steps_daily_aggregated","{}") ?: "{}"))
            put("workoutsToday",sumToday("workout")?:JSONObject.NULL)
            put("activeCaloriesToday",sumToday("active_calories")?:JSONObject.NULL)
            put("distanceToday",sumToday("distance")?:JSONObject.NULL)
            put("records",arr)
        }
    }

    fun exportJson(context:Context):String {
        val s=snapshot(context)
        return JSONObject().apply {
            put("schemaVersion","1.0")
            put("app","Healther")
            put("generatedAt",ZonedDateTime.now().toOffsetDateTime().toString())
            put("period",JSONObject().apply {
                put("start",ZonedDateTime.now().minusDays(30).toOffsetDateTime().toString())
                put("end",ZonedDateTime.now().toOffsetDateTime().toString())
            })
            put("measurements",s.getJSONArray("records"))
            put("notes",context.getSharedPreferences(PREFS,0).getString("report_note","") ?: "")
            put("gaps",JSONArray()) // Unknown coverage is not falsely claimed complete.
            put("coverageStatus","not_verified")
        }.toString(2)
    }
    fun exportMarkdown(context:Context):String {
        val s=snapshot(context)
        val arr=s.getJSONArray("records")
        val out=StringBuilder("# Healther — דוח מדידות\n\n")
            .append("נוצר: ").append(ZonedDateTime.now().toOffsetDateTime()).append("\n\n")
            .append("מקור: Health Connect (אם ניתנה הרשאה ונמצאו רשומות).\n")
            .append("ערכים חסרים אינם מתוארים כאפס. אין כאן אבחון רפואי.\n\n")
            .append("| מדד | ערך | יחידה | נמדד בתאריך | מקור |\n")
            .append("|---|---:|---|---|---|\n")
        if(arr.length()==0)out.append("| אין מדידות זמינות | — | — | — | — |\n")
        for(i in 0 until arr.length()) {
            val r=arr.optJSONObject(i) ?:continue
            out.append("| ").append(r.optString("metric"))
                .append(" | ").append(r.optString("value"))
                .append(" | ").append(r.optString("unit"))
                .append(" | ").append(r.optString("measuredAt"))
                .append(" | ").append(r.optString("source")).append(" |\n")
        }
        out.append("\nכיסוי וחוסרים: עדיין לא חושב באימות מלא; אין להסיק רציפות מהיעדר סימון.\n")
        val note=context.getSharedPreferences(PREFS,0).getString("report_note","")?.trim()
        if(!note.isNullOrEmpty())out.append("\n## הערות אישיות\n").append(note.replace("|","\\|")).append("\n")
        return out.toString()
    }
}
