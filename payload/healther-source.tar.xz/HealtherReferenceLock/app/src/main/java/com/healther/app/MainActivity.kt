package com.healther.app

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.HealthConnectFeatures
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private lateinit var browser: WebView
    private val routeMap = listOf(
        "welcome","privacy_intro","connect","permissions","first_sync","setup_done",
        "dashboard","dashboard_more","metrics_hub","notifications","heart","heart_history",
        "heart_compare","oxygen","oxygen_sleep","oxygen_history","sleep","sleep_night",
        "sleep_history","steps","steps_day","steps_30","activity","workout",
        "activity_history","body","body_history","body_comp","history_hub",
        "history_metric","history_day","history_filter","reports","report_range",
        "report_preview","report_notes","report_export","report_share","export_success",
        "ai_handoff","goals","goal_steps","goal_weight","settings","source_detail",
        "sources","permissions_settings","sync_settings","privacy_settings",
        "appearance","about","empty_all","no_permissions","sync_error","loading",
        "stale","missing_days","offline","dialog_delete","dialog_date"
    )
    private var currentPage="welcome"
    private var pendingExport="md"
    private val permissionRequest=registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { _ ->
        lifecycleScope.launch {
            val prefs=getSharedPreferences(HealthStore.PREFS,0)
            val hasDataAccess=runCatching {
                HealthConnectClient.getOrCreate(this@MainActivity)
                    .permissionController.getGrantedPermissions()
                    .any {it in HealthStore.recordPermissions}
            }.getOrDefault(false)
            if (!hasDataAccess) {
                toast("לא אושרה הרשאה לקריאת מדדים")
                if (currentPage=="permissions") showPage("no_permissions")
                return@launch
            }
            if(prefs.getBoolean("auto_sync",false)) {
                val scheduled=BackgroundScheduling.setEnabled(this@MainActivity,true)
                if(!scheduled) {
                    prefs.edit().putBoolean("auto_sync",false).apply()
                    toast("סנכרון ברקע אינו מאושר או אינו נתמך במכשיר")
                }
            }
            if(currentPage=="permissions")showPage("first_sync") else syncNow()
        }
    }
    private val saveDocument=registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if(result.resultCode!=Activity.RESULT_OK)return@registerForActivityResult
        val uri=result.data?.data ?:return@registerForActivityResult
        try {
            val body=if(pendingExport=="json")HealthStore.exportJson(this) else HealthStore.exportMarkdown(this)
            val stream=contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("לא ניתן לפתוח קובץ לכתיבה")
            stream.use {out->out.write(body.toByteArray(Charsets.UTF_8))}
            toast("הדוח נשמר במכשיר")
            showPage("export_success")
        } catch(e:Exception){toast("שגיאה בשמירת הקובץ: ${e.localizedMessage}")}
    }

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window,false)
        val root=FrameLayout(this)
        browser=WebView(this)
        root.addView(browser,FrameLayout.LayoutParams(-1,-1))
        ViewCompat.setOnApplyWindowInsetsListener(root) { view,insets ->
            val bars=insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left,bars.top,bars.right,bars.bottom)
            insets
        }
        setContentView(root)
        @Suppress("SetJavaScriptEnabled")
        browser.settings.javaScriptEnabled=true
        browser.settings.domStorageEnabled=false
        browser.settings.allowContentAccess=false
        browser.settings.allowFileAccess=true // only packaged assets; all external URLs blocked
        browser.settings.allowFileAccessFromFileURLs=false
        browser.settings.allowUniversalAccessFromFileURLs=false
        browser.settings.setSupportMultipleWindows(false)
        browser.addJavascriptInterface(JsInterface(),"HealtherHost")
        browser.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean {
                val url=request.url.toString()
                return !url.startsWith("file:///android_asset/screens/")
            }
            override fun onPageFinished(view:WebView?,url:String?) {
                super.onPageFinished(view,url)
                // Keep back-navigation state consistent with the visible WebView route.
                val openedFile=Uri.parse(url ?: "").lastPathSegment.orEmpty()
                    .removePrefix("dark_").removeSuffix(".html")
                val openedPage=openedFile.replace(Regex("^\\d{2}_"),"")
                if (openedPage in routeMap) currentPage=openedPage
                // Native Android bars replace the reference-only simulated system bars.
                browser.evaluateJavascript("(function(){var x=document.createElement('style');"+
                   "x.textContent='.statusbar,.system-gesture{display:none!important}.phone{height:100dvh;max-height:none!important;max-width:none!important}';"+
                   "document.head.appendChild(x);})()",null)
            }
        }
        currentPage=savedInstanceState?.getString("page") ?: if(
            getSharedPreferences(HealthStore.PREFS,0).getBoolean("onboarded",false)
        )"dashboard" else "welcome"
        showPage(currentPage)
        setNativeBarColors()
        // Resynchronization is best-effort and is only attempted after a previous successful connection.
        if(getSharedPreferences(HealthStore.PREFS,0).getString("last_sync",null)!=null) syncNow(false)
    }

    override fun onSaveInstanceState(outState:Bundle) {
        outState.putString("page",currentPage)
        super.onSaveInstanceState(outState)
    }

    private fun darkTheme():Boolean {
        val theme=getSharedPreferences(HealthStore.PREFS,0).getString("theme","system")
        return theme=="dark" || (theme=="system" &&
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES)
    }
    private fun setNativeBarColors() {
        val dark=darkTheme()
        window.statusBarColor=if(dark)Color.rgb(18,27,25) else Color.rgb(246,248,247)
        window.navigationBarColor=window.statusBarColor
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility=if(dark)0 else
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }
    private fun showPage(name:String) {
        val index=routeMap.indexOf(name)
        if(index<0)return
        currentPage=name
        if(name=="dashboard")getSharedPreferences(HealthStore.PREFS,0).edit().putBoolean("onboarded",true).apply()
        val f="${(index+1).toString().padStart(2,'0')}_${name}.html"
        browser.loadUrl("file:///android_asset/screens/${if(darkTheme()) "dark_" else ""}$f")
    }
    private fun toast(message:String)=Toast.makeText(this,message,Toast.LENGTH_SHORT).show()
    private fun syncNow(notify:Boolean=true) {
        lifecycleScope.launch {
            val success=HealthStore.synchronize(this@MainActivity)
            if(notify)toast(if(success)"קריאת נתונים הסתיימה" else
                "לא ניתן לסנכרן. בדוק הרשאות וזמינות Health Connect")
            val snapshot=JSONObject.quote(HealthStore.snapshot(this@MainActivity).toString())
            browser.evaluateJavascript("window.HealtherReferenceLock?.applySnapshot(JSON.parse($snapshot));",null)
            if(currentPage=="first_sync")showPage(if(success)"setup_done" else "sync_error")
        }
    }
    private fun requestPermissions() {
        lifecycleScope.launch {
            if(!HealthStore.available(this@MainActivity)) {
                toast("Health Connect אינו זמין; יש להתקין או לעדכן אותו במכשיר")
                return@launch
            }
            val requested=HealthStore.recordPermissions.toMutableSet()
            val client=HealthConnectClient.getOrCreate(this@MainActivity)
            val bgSupported=client.features.getFeatureStatus(HealthConnectFeatures.FEATURE_READ_HEALTH_DATA_IN_BACKGROUND)==
                HealthConnectFeatures.FEATURE_STATUS_AVAILABLE
            if(bgSupported && getSharedPreferences(HealthStore.PREFS,0).getBoolean("auto_sync",false)){
                requested.add(HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND)
            }
            permissionRequest.launch(requested)
        }
    }
    private fun startExport(ext:String){
        pendingExport=if(ext=="json")"json" else "md"
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type=if(pendingExport=="json")"application/json" else "text/markdown"
            putExtra(Intent.EXTRA_TITLE,"healther-report-${LocalDate.now()}.$pendingExport")
        }
        saveDocument.launch(i)
    }
    private fun startShare(ext:String){
        try {
            val isJson=ext=="json"
            val file=File(cacheDir,"healther-report.${if(isJson)"json" else "md"}")
            file.writeText(if(isJson)HealthStore.exportJson(this) else HealthStore.exportMarkdown(this))
            val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",file)
            val share=Intent(Intent.ACTION_SEND).apply {
                type=if(isJson)"application/json" else "text/markdown"
                putExtra(Intent.EXTRA_STREAM,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(share,"שיתוף דוח Healther"))
        }catch(e:Exception){toast("לא ניתן לשתף: ${e.localizedMessage}")}
    }
    inner class JsInterface {
        @JavascriptInterface fun getSnapshot():String=HealthStore.snapshot(this@MainActivity).toString()
        @JavascriptInterface fun navigate(page:String)=runOnUiThread {showPage(page)}
        @JavascriptInterface fun toast(message:String)=runOnUiThread {this@MainActivity.toast(message.take(180))}
        @JavascriptInterface fun requestPermissions()=runOnUiThread {this@MainActivity.requestPermissions()}
        @JavascriptInterface fun syncNow()=runOnUiThread {this@MainActivity.syncNow()}
        @JavascriptInterface fun saveGoal(value:Int)=runOnUiThread {
            if(value in 1000..100000)HealthStore.setGoal(this@MainActivity,value)
        }
        @JavascriptInterface fun setReportNote(note:String)=runOnUiThread {
            getSharedPreferences(HealthStore.PREFS,0).edit().putString("report_note",note.take(2000)).apply()
        }
        @JavascriptInterface fun exportReport(format:String)=runOnUiThread {startExport(format)}
        @JavascriptInterface fun shareReport(format:String)=runOnUiThread {startShare(format)}
        @JavascriptInterface fun deleteLocalHistory()=runOnUiThread {
            lifecycleScope.launch {
                BackgroundScheduling.setEnabled(this@MainActivity,false)
                HealthStore.clear(this@MainActivity)
                toast("היסטוריה מקומית נמחקה והסנכרון ברקע הושהה. מקורות חיצוניים לא נמחקו")
                showPage("dashboard")
            }
        }
        @JavascriptInterface fun setTheme(mode:String)=runOnUiThread {
            if(mode !in listOf("light","dark","system"))return@runOnUiThread
            getSharedPreferences(HealthStore.PREFS,0).edit().putString("theme",mode).apply()
            setNativeBarColors();showPage("appearance")
        }
        @JavascriptInterface fun setAutoSync(enabled:Boolean)=runOnUiThread {
            lifecycleScope.launch {
                if(enabled){
                    getSharedPreferences(HealthStore.PREFS,0).edit().putBoolean("auto_sync",true).apply()
                    // Scheduling happens only after the permission-result callback succeeds.
                    requestPermissions()
                } else {
                    getSharedPreferences(HealthStore.PREFS,0).edit().putBoolean("auto_sync",false).apply()
                    BackgroundScheduling.setEnabled(this@MainActivity,false)
                }
            }
        }
    }
    @Deprecated("Legacy back support until verified with target devices")
    override fun onBackPressed() {
        if(browser.canGoBack())browser.goBack()
        else if(currentPage!="dashboard")showPage("dashboard")
        else super.onBackPressed()
    }
    override fun onDestroy(){browser.removeJavascriptInterface("HealtherHost");browser.destroy();super.onDestroy()}
}
