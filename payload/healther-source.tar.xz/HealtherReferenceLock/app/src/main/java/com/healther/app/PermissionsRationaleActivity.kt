package com.healther.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView

/** This is also reachable from the Health Connect permission dialog. */
class PermissionsRationaleActivity:Activity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        val v=WebView(this)
        v.settings.javaScriptEnabled=false
        setContentView(v)
        v.loadDataWithBaseURL(null,"""
          <!doctype html><html lang="he" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
          <style>body{font:16px sans-serif;background:#f6f8f7;color:#1b2825;padding:24px;line-height:1.7}
          h1{font-size:26px}p{max-width:35em}</style>
          <h1>Healther — פרטיות והרשאות</h1>
          <p>האפליקציה קוראת רק נתוני בריאות שהרשית במפורש דרך Health Connect: דופק, חמצן בדם, שינה, צעדים, משקל, אימונים, מרחק וקלוריות פעילות.</p>
          <p>המדידות נשמרות באופן מקומי באזור האחסון הפרטי של האפליקציה. לא מתבצעת העלאה לשרת ולא מועבר מידע לצד שלישי ללא פעולה שלך.</p>
          <p>ניתן לבטל הרשאות דרך הגדרות Health Connect, למחוק את העותק המקומי ולייצא דוח ביוזמתך. מחיקה מקומית אינה מוחקת את הנתונים מהשעון או ממקורות חיצוניים.</p>
          <p>נתוני הבריאות אינם מחליפים ייעוץ רפואי. נתוני Samsung Health יוצגו רק אם הם זמינים דרך Health Connect ובהרשאות שקיבלת.</p>
          </html>
        """.trimIndent(),"text/html","utf-8",null)
    }
}
