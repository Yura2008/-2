Reference artwork is user-provided and approved. Original unslop © Damir Sokolovsky (@heydamir), licensed CC BY 4.0, adapted for ChatGPT.
https://github.com/heydamir/unslop
