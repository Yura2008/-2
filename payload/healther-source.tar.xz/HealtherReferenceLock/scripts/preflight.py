"""Fast, dependency-free pre-build audit. Does NOT compile Android code."""
from pathlib import Path
import json, xml.etree.ElementTree as ET, hashlib
r=Path(__file__).resolve().parents[1]
assets=r/'app/src/main/assets'
js=(assets/'healther-runtime.js').read_text()
main=r/'app/src/main/java/com/healther/app/MainActivity.kt'
bg=r/'app/src/main/java/com/healther/app/BackgroundSyncWorker.kt'
android_ns='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
assert manifest.find('application') is not None
for f in (r/'app/src/main/res/values/colors.xml',r/'app/src/main/res/xml/file_paths.xml'):
    ET.parse(f)
assert 'android.permission.health.READ_HEART_RATE' in [x.get(android_ns+'name') for x in manifest.findall('uses-permission')]
assert 'android.permission.health.READ_STEPS' in [x.get(android_ns+'name') for x in manifest.findall('uses-permission')]
assert 'import androidx.health.connect.client.HealthConnectFeatures' in main.read_text()
assert 'import androidx.health.connect.client.HealthConnectFeatures' in bg.read_text()
assert 'client.aggregateGroupByPeriod(' in (r/'app/src/main/java/com/healther/app/HealthStore.kt').read_text()
assert 'window.HealtherReferenceLock={page,navigate,applySnapshot}' in js
routes=json.loads((assets/'screen-manifest.json').read_text())
assert len(routes)==60,len(routes)
for row in routes:
    fname=row['filename'].replace('.png','.html')
    for name in (fname,'dark_'+fname):
        content=(assets/'screens'/name).read_text()
        assert '../healther-runtime.js' in content,name
        assert '<html lang="he" dir="rtl">' in content,name
        assert '<style>' in content,name
assert len(list((assets/'screens').glob('*.html')))==120
print('PASS preflight: manifest/resources XML, Health Connect imports, 120 RTL screens, runtime/assets')
print('APK compilation: NOT checked by preflight')
