"""Browser-only mock Health Connect QA; does NOT replace Android device tests."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
JS=(ASSETS/'healther-runtime.js').read_text()
assert len(list((ASSETS/'screens').glob('*.html')))==120
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=2)
    errors=[]
    page.on('pageerror',lambda exc: errors.append(str(exc)))
    # No credentials or user measurements. Values below are explicitly fictional test fixtures.
    fixture={'schemaVersion':'1.0','app':'Healther','syncedAt':'2026-11-07T08:36:00+02:00',
        'stepGoal':10000,'latestHeart':{'value':76,'measuredAt':'2026-11-07T08:35:00+02:00','source':'test'},
        'latestOxygen':{'value':98,'measuredAt':'2026-11-07T07:52:00+02:00','source':'test'},
        'latestWeight':{'value':74.2,'measuredAt':'2026-11-06T08:12:00+02:00','source':'test'},
        'lastSleep':{'value':480,'measuredAt':'2026-11-07T07:24:00+02:00','source':'test'},
        'todaySteps':{'value':9246},'workoutsToday':{'value':1},'activeCaloriesToday':{'value':412},
        'distanceToday':{'value':6.1},'records':[],'dailySteps':{}}
    fixtures=[('none',dict(fixture,**{k:None for k in ['latestHeart','latestOxygen','latestWeight','lastSleep','todaySteps','workoutsToday','activeCaloriesToday','distanceToday']},syncedAt=None,dailySteps={})),
              ('values',fixture)]
    for state,data in fixtures:
        for screen in ('07_dashboard.html','20_steps.html','dark_07_dashboard.html','dark_20_steps.html'):
            page.set_content((ASSETS/'screens'/screen).read_text(),wait_until='load')
            page.evaluate('(data) => {window.HealtherHost={getSnapshot:()=>JSON.stringify(data),navigate:()=>{},toast:()=>{}};}',data)
            page.add_script_tag(content=JS.replace(
                "const fileName = location.pathname.split('/').pop() || '07_dashboard.html';",
                "const fileName = '" + screen + "';"))
            assert page.evaluate('window.HealtherReferenceLock?.page') in ('dashboard','steps'),screen
            if screen.endswith('07_dashboard.html'):
                text=page.locator('.phone').inner_text()
                for old in ('7,842','2,158','7,926','23:48–07:24','78.4','08:35'):
                    assert old not in text,(state,screen,old)
                if state=='none':
                    assert 'אין מדידות מסונכרנות' in text
                    assert 'אין נתוני צעדים להיום' in text
                    assert 'אין מדידה זמינה' in text
                else:
                    assert '9,246' in text
                    assert '74.2' in text
                    assert '6.1' in text
                    assert '412' in text
            if screen.endswith('20_steps.html'):
                assert page.locator('svg.chart-svg').get_attribute('aria-label')=='צעדים ל-14 ימים לפי Health Connect'
                assert page.locator('svg.chart-svg rect[stroke-dasharray]').count()>=14
    assert not errors,errors
    b.close()
print('PASS: 8 browser runtime cases (no-data/fictional sample, light/dark, dashboard/steps); no JS page errors')
